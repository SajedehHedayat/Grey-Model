
function fobj= Get_Functions_detailsCEC(F)
switch F
    case 'F1'
        
       fobj = @F1;
        
  
 end
end

function z = F1(param, X1_predicted)

sum = 0;

for i=2:length(X1_predicted)

sum = sum+((X1_predicted(i)-...
    (X1_predicted(i-1)+param(1)*X1_predicted(i-1)^param(2)+param(3)*X1_predicted(i-1)^param(4)))^2);

end
z = (1/length(X1_predicted))*sum+max(0,-2*param(4)+param(2)+1);
end
