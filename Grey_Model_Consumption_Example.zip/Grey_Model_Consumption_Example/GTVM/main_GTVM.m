clear all
close all
clc


VarMin = -2*ones(1,5);       
VarMax = 2*ones(1,5);
%% China's energy consumption

T0 = [230.281, 261.369, 286.467, 311.442, 320.611, 336.126,360.648, 387.043, 402.138, 416.913, 428.334, 434.113, 441.492, 455.827]*1000;
T0_test = [ 471.925, 487.488, 498.314, 525.896, 541.000, 572.000]*1000;

%% Algorithm

X0=1./T0;
% X0 = T0./T0(1);
X1 = cumsum(X0);

[result] = pso1(X1, VarMin, VarMax);

sigma_opt = result.Position(1);
a_opt = result.Position(2);
b_opt = result.Position(3);
c_opt = result.Position(4);
d_opt = result.Position(5);

disp('Optimal value of parameters:')
disp(result.Position)


X1_predicted(1) = X1(1);
for i=2:(length(X1)+length(T0_test))

    X1_predicted(i) = sigma_opt*X1_predicted(i-1)+a_opt*i^2+...
        b_opt*i+c_opt+d_opt*(i-1);
end

X0_predicted(1) = X1_predicted(1);

for i=2:(length(X0)+length(T0_test))
     X0_predicted(i) = X1_predicted(i)-X1_predicted(i-1);
end

X0_predicted_final_GTVM = 1./X0_predicted;

%% APE Train
for i=1:length(T0)
    err_GTVM(i) = (abs(X0_predicted_final_GTVM(i)-T0(i))/T0(i))*100;

end

%% MAPE Train
m_GTVM_err=mean(err_GTVM(1:length(T0)));

%% MAE Train
for i=1:length(T0)
    AEerr_GTVM(i) = abs(X0_predicted_final_GTVM(i)-T0(i));

end
MAE_GTVM = mean(AEerr_GTVM(1:length(T0)));

%% MSE Train
for i=1:length(T0)
    SEerr_GTVM(i) = (X0_predicted_final_GTVM(i)-T0(i))^2;

end
MSE_GTVM = mean(SEerr_GTVM(1:length(T0)));

%% RMSPE Train
for i=1:length(T0)
    SPE_GTVM(i) = (((X0_predicted_final_GTVM(i)-T0(i))/T0(i))^2)*100;

end
RMSPE_GTVM = sqrt(mean(SPE_GTVM(1:length(T0))));
%% IA Train
for i=1:length(T0)
    IA_1(i)=(X0_predicted_final_GTVM(i)-T0(i))^2;
    IA_2(i)=(abs(X0_predicted_final_GTVM(i)-mean(T0))+abs(mean(T0)-T0(i)))^2;
end
IA_GTVM = 1-(sum(IA_1)/sum(IA_2));

%% R Train
R_GTVM = cov(T0, X0_predicted_final_GTVM(1:length(T0)))/sqrt(var(T0)*var(X0_predicted_final_GTVM(1:length(T0))));

%% display Train
disp('err _GTVM:');
disp(m_GTVM_err)

disp('MAE _GTVM:');
disp(MAE_GTVM)

disp('MSE _GTVM:');
disp(MSE_GTVM)

disp('RMSPE _GTVM');
disp(RMSPE_GTVM);

disp('IA _GTVM');
disp(IA_GTVM);

disp(' R _GTVM');
disp(R_GTVM)

%% APE Test
for i=(length(T0)+1):(length(X0)+length(T0_test))
    err_GTVM_test(i) = (abs(X0_predicted_final_GTVM(i)-T0_test(i-(length(T0))))/T0_test(i-(length(T0))))*100;

end

%% MAPE Test
m_GTVM_err_test=mean(err_GTVM_test(length(T0)+1:length(T0_test)+length(T0)));

%% MAE Test
for i=(length(T0)+1):(length(X0)+length(T0_test))
    AE_GTVM_test(i) = abs(X0_predicted_final_GTVM(i)-T0_test(i-(length(T0))));

end
MAE_GTVM_test = mean(AE_GTVM_test(length(T0)+1:length(T0_test)+length(T0)));

%% MSE Test
for i=(length(T0)+1):(length(X0)+length(T0_test))
    SE_GTVM_test(i) = (X0_predicted_final_GTVM(i)-T0_test(i-(length(T0))))^2;

end
MSE_GTVM_test = mean(SE_GTVM_test(length(T0)+1:length(T0_test)+length(T0)));

%% RMSPE Test
for i=(length(T0)+1):(length(X0)+length(T0_test))
    SPE_GTVM_test(i) = (((X0_predicted_final_GTVM(i)-T0_test(i-(length(T0))))/T0_test(i-(length(T0))))^2)*100;

end
RMSPE_GTVM_test = sqrt(mean(SPE_GTVM_test(length(T0)+1:length(T0_test)+length(T0))));

%% IA Test
for i=(length(T0)+1):(length(X0)+length(T0_test))
    IA_1_test(i) = (X0_predicted_final_GTVM(i)-T0_test(i-(length(T0))))^2;
    IA_2_test(i) = (abs(X0_predicted_final_GTVM(i)-mean(T0_test))+abs(mean(T0_test)-T0_test(i-(length(T0)))))^2;
end
IA_GTVM_test = 1-(sum(IA_1_test)/sum(IA_2_test));

%% R Train
R_GTVM_test = cov(T0_test, X0_predicted_final_GTVM(length(T0)+1:length(T0_test)+length(T0)))/sqrt(var(T0_test)*var(X0_predicted_final_GTVM(length(T0)+1:length(T0_test)+length(T0))));

%% display Test
disp('test err _GTVM:');
disp(m_GTVM_err_test)

disp('test MAE _GTVM:');
disp(MAE_GTVM_test)

disp('test MSE _GTVM:');
disp(MSE_GTVM_test)

disp('test RMSPE _GTVM');
disp(RMSPE_GTVM_test);

disp('test IA _GTVM');
disp(IA_GTVM_test);

disp('test R _GTVM');
disp(R_GTVM_test)

% disp('Original input:')
% disp(X0)
% disp('Predicted result using Grey Verhulst model:')
% disp(X0_predicted)
% 
% disp('Original input:')
% disp(T0)
% disp('Predicted result using Grey Verhulst model:')
% disp(X0_predicted_final)
% 
% figure
% plot(1:1:length(T0),T0,'-o','LineWidth',2)
% hold on
% plot(1:1:length(X0_predicted_final),X0_predicted_final,'-*','LineWidth',2)