function [BestSol] = pso1(input, VarMin, VarMax)
%% Problem Definition

CostFunction = @(x,y) obj_func(x,y);        % Cost Function

nVar = 3;            % Number of Decision Variables

VarSize = [1 nVar];   % Size of Decision Variables Matrix

%% PSO Parameters

MaxIt = 300;      % Maximum Number of Iterations

nPop = 30;        % Population Size (Swarm Size)

% PSO Parameters
w = 0.9;            % Inertia Weight
wdamp = 0.99;     % Inertia Weight Damping Ratio
c1 = 1.49;         % Personal Learning Coefficient
c2 = 1.49;         % Global Learning Coefficient

n = length(input);

% If you would like to use Constriction Coefficients for PSO, 
% uncomment the following block and comment the above set of parameters.

% % Constriction Coefficients
% phi1 = 2.05;
% phi2 = 2.05;
% phi = phi1+phi2;
% chi = 2/(phi-2+sqrt(phi^2-4*phi));
% w = chi;          % Inertia Weight
% wdamp = 1;        % Inertia Weight Damping Ratio
% c1 = chi*phi1;    % Personal Learning Coefficient
% c2 = chi*phi2;    % Global Learning Coefficient

% Velocity Limits
VelMax = 0.1*(VarMax-VarMin);
VelMin = -VelMax;

%% Initialization

empty_particle.Position = [];
empty_particle.Cost = [];
empty_particle.Velocity = [];
empty_particle.Best.Position = [];
empty_particle.Best.Cost = [];

particle = repmat(empty_particle, nPop, 1);

GlobalBest.Cost = inf;

for i = 1:nPop
    
    % Initialize Position
    particle(i).Position = unifrnd(VarMin, VarMax, VarSize);
    
    particle(i).Position = max(particle(i).Position, VarMin);
    particle(i).Position = min(particle(i).Position, VarMax);
    
    % Initialize Velocity
    particle(i).Velocity = zeros(VarSize);
    
    param = particle(i).Position;
%     X1_predicted(1) = input(1);
%     for j=2:n
%         X1_predicted(j) = param(1)*input(j-1)+param(2)*j^2+param(3)*j+param(4)+param(5)*(j-1);
%         %         X1_predicted(j) = param(1)*input(j-1)+param(2)*(j-1)+param(4);
%     end
    X1_predicted = input;
    % Evaluation
    particle(i).Cost = CostFunction(particle(i).Position, X1_predicted);
    
    % Update Personal Best
    particle(i).Best.Position = particle(i).Position;
    particle(i).Best.Cost = particle(i).Cost;
    
    % Update Global Best
    if particle(i).Best.Cost<GlobalBest.Cost
        
        GlobalBest = particle(i).Best;
        
    end
    
end

BestCost = zeros(MaxIt, 1);

%% PSO Main Loop

for it = 1:MaxIt
    
%     if it<2
%         w = w*2;
%     end
%     if it>5
%         w = w/2;
%     end
    
    for i = 1:nPop
        
        % Update Velocity
        particle(i).Velocity = w*particle(i).Velocity ...
            +c1*rand(VarSize).*(particle(i).Best.Position-particle(i).Position) ...
            +c2*rand(VarSize).*(GlobalBest.Position-particle(i).Position);
        
        % Apply Velocity Limits
        particle(i).Velocity = max(particle(i).Velocity, VelMin);
        particle(i).Velocity = min(particle(i).Velocity, VelMax);
        
        % Update Position
        particle(i).Position = particle(i).Position + particle(i).Velocity;
        
        % Velocity Mirror Effect
        IsOutside = (particle(i).Position<VarMin | particle(i).Position>VarMax);
        particle(i).Velocity(IsOutside) = -particle(i).Velocity(IsOutside);
        
        % Apply Position Limits
        particle(i).Position = max(particle(i).Position, VarMin);
        particle(i).Position = min(particle(i).Position, VarMax);
        
        
        param = particle(i).Position;
%         X1_predicted(1) = input(1);
%         for j=2:n
%             X1_predicted(j) = param(1)*input(j-1)+param(2)*j^2+param(3)*j+param(4)+param(5)*(j-1);
% %             X1_predicted(j) = param(1)*input(j-1)+param(2)*(j-1)+param(4);
%         end
        
        % Evaluation
        particle(i).Cost = CostFunction(particle(i).Position, X1_predicted);
        
        % Update Personal Best
        if particle(i).Cost<particle(i).Best.Cost
            
            particle(i).Best.Position = particle(i).Position;
            particle(i).Best.Cost = particle(i).Cost;
            
            % Update Global Best
            if particle(i).Best.Cost<GlobalBest.Cost
                
                GlobalBest = particle(i).Best;
                
            end
            
        end
        
    end
    
    BestCost(it) = GlobalBest.Cost;
    
%     disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
    
    w = w*wdamp;
    
end

BestSol = GlobalBest;

%% Results

% figure;
% %plot(BestCost, 'LineWidth', 2);
% semilogy(BestCost, 'LineWidth', 2);
% xlabel('Iteration');
% ylabel('Best Cost');
% grid on;
