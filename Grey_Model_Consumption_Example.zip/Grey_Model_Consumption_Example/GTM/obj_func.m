
function z = obj_func(param, X1_predicted)

sum = 0;

for i=2:length(X1_predicted)
    
    sum = sum+(X1_predicted(i)-(param(1)*X1_predicted(i-1)+param(3)+param(2)*(i-1)))^2;
  
end

z = (1/length(X1_predicted))*sum;

end
