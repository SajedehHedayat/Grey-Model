clear all
close all
clc


VarMin = -2*ones(1,3);       
VarMax = 2*ones(1,3);
%% China's energy consumption
T0 = [230.281, 261.369, 286.467, 311.442, 320.611, 336.126,360.648, 387.043, 402.138, 416.913, 428.334, 434.113, 441.492, 455.827]*1000;
T0_test = [ 471.925, 487.488, 498.314, 525.896, 541.000, 572.000]*1000;

%% Algorithm

X0=1./T0;
% X0 = T0./T0(1);
X1 = cumsum(X0);

[result] = pso1(X1, VarMin, VarMax);

sigma_opt = result.Position(1);
a_opt = result.Position(2);
b_opt = result.Position(3);


disp('Optimal value of parameters:')
disp(result.Position)


X1_predicted(1) = X1(1);
for i=2:(length(X1)+length(T0_test))

    X1_predicted(i) = sigma_opt*X1_predicted(i-1)+...
        +b_opt+a_opt*(i-1);
end

X0_predicted(1) = X1_predicted(1);

for i=2:(length(X0)+length(T0_test))
     X0_predicted(i) = X1_predicted(i)-X1_predicted(i-1);
end

X0_predicted_final_GTM = 1./X0_predicted;

%% APE Train
for i=1:length(T0)
    err_GTM(i) = (abs(X0_predicted_final_GTM(i)-T0(i))/T0(i))*100;

end

%% MAPE Train
m_GTM_err=mean(err_GTM(1:length(T0)));

%% MAE Train
for i=1:length(T0)
    AEerr_GTM(i) = abs(X0_predicted_final_GTM(i)-T0(i));

end
MAE_GTM = mean(AEerr_GTM(1:length(T0)));

%% MSE Train
for i=1:length(T0)
    SEerr_GTM(i) = (X0_predicted_final_GTM(i)-T0(i))^2;

end
MSE_GTM = mean(SEerr_GTM(1:length(T0)));

%% RMSPE Train
for i=1:length(T0)
    SPE_GTM(i) = (((X0_predicted_final_GTM(i)-T0(i))/T0(i))^2)*100;

end
RMSPE_GTM = sqrt(mean(SPE_GTM(1:length(T0))));
%% IA Train
for i=1:length(T0)
    IA_1(i)=(X0_predicted_final_GTM(i)-T0(i))^2;
    IA_2(i)=(abs(X0_predicted_final_GTM(i)-mean(T0))+abs(mean(T0)-T0(i)))^2;
end
IA_GTM = 1-(sum(IA_1)/sum(IA_2));

%% R Train
R_GTM = cov(T0, X0_predicted_final_GTM(1:length(T0)))/sqrt(var(T0)*var(X0_predicted_final_GTM(1:length(T0))));

%% display Train
disp('err _GTM:');
disp(m_GTM_err)

disp('MAE _GTM:');
disp(MAE_GTM)

disp('MSE _GTM:');
disp(MSE_GTM)

disp('RMSPE _GTM');
disp(RMSPE_GTM);

disp('IA _GTM');
disp(IA_GTM);

disp(' R _GTM');
disp(R_GTM)

%% APE Test
for i=(length(T0)+1):(length(X0)+length(T0_test))
    err_GTM_test(i) = (abs(X0_predicted_final_GTM(i)-T0_test(i-(length(T0))))/T0_test(i-(length(T0))))*100;

end

%% MAPE Test
m_GTM_err_test=mean(err_GTM_test(length(T0)+1:length(T0_test)+length(T0)));

%% MAE Test
for i=(length(T0)+1):(length(X0)+length(T0_test))
    AE_GTM_test(i) = abs(X0_predicted_final_GTM(i)-T0_test(i-(length(T0))));

end
MAE_GTM_test = mean(AE_GTM_test(length(T0)+1:length(T0_test)+length(T0)));

%% MSE Test
for i=(length(T0)+1):(length(X0)+length(T0_test))
    SE_GTM_test(i) = (X0_predicted_final_GTM(i)-T0_test(i-(length(T0))))^2;

end
MSE_GTM_test = mean(SE_GTM_test(length(T0)+1:length(T0_test)+length(T0)));

%% RMSPE Test
for i=(length(T0)+1):(length(X0)+length(T0_test))
    SPE_GTM_test(i) = (((X0_predicted_final_GTM(i)-T0_test(i-(length(T0))))/T0_test(i-(length(T0))))^2)*100;

end
RMSPE_GTM_test = sqrt(mean(SPE_GTM_test(length(T0)+1:length(T0_test)+length(T0))));

%% IA Test
for i=(length(T0)+1):(length(X0)+length(T0_test))
    IA_1_test(i) = (X0_predicted_final_GTM(i)-T0_test(i-(length(T0))))^2;
    IA_2_test(i) = (abs(X0_predicted_final_GTM(i)-mean(T0_test))+abs(mean(T0_test)-T0_test(i-(length(T0)))))^2;
end
IA_GTM_test = 1-(sum(IA_1_test)/sum(IA_2_test));

%% R Train
R_GTM_test = cov(T0_test, X0_predicted_final_GTM(length(T0)+1:length(T0_test)+length(T0)))/sqrt(var(T0_test)*var(X0_predicted_final_GTM(length(T0)+1:length(T0_test)+length(T0))));

%% display Test
disp('test err _GTM:');
disp(m_GTM_err_test)

disp('test MAE _GTM:');
disp(MAE_GTM_test)

disp('test MSE _GTM:');
disp(MSE_GTM_test)

disp('test RMSPE _GTM');
disp(RMSPE_GTM_test);

disp('test IA _GTM');
disp(IA_GTM_test);

disp('test R _GTM');
disp(R_GTM_test)
