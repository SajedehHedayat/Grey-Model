clear all
close all
clc

%% China's energy consumption
% 
T0 = [230.281, 261.369, 286.467, 311.442, 320.611, 336.126,360.648, 387.043, 402.138, 416.913, 428.334, 434.113, 441.492, 455.827]*1000;
T0_test = [ 471.925, 487.488, 498.314, 525.896, 541.000, 572.000]*1000;
%% Algorithm

X0=1./T0;
X0 = T0./T0(1);
X1 = cumsum(T0);
z(1)=0;
for i=2:length(T0)
   z(i)=0.5*(X1(i)+X1(i-1)); 
end
y=[ -z(2) 1; -z(3) 1; -z(4) 1;-z(5) 1;-z(6) 1; -z(7) 1; -z(8) 1; -z(9) 1; -z(10) 1;-z(11) 1;-z(12) 1; -z(13) 1; -z(14) 1];

omega=T0(2:length(T0))';
g=y'*y;
k=y'*omega;
i=inv(g);
h=i*k;

for k=1:length(T0)+length(T0_test)
    s1(k) = ((T0(1))-(h(2)/h(1)))*exp(-h(1)*(k-1))+h(2)/h(1);
end

s0(1)=T0(1);
for k=2:length(T0)+length(T0_test)
   s0(k)= s1(k)-s1(k-1);
end
X0_predicted_final_von=s0;
test_von = s0((length(T0)+1):(length(T0)+length(T0_test)));

%% APE Train
for i=1:length(T0)
    err_von(i) = (abs(X0_predicted_final_von(i)-T0(i))/T0(i))*100;

end

%% MAPE Train
m_von_err=mean(err_von(1:length(T0)));

%% MAE Train
for i=1:length(T0)
    AEerr_von(i) = abs(X0_predicted_final_von(i)-T0(i));

end
MAE_von = mean(AEerr_von(1:length(T0)));

%% MSE Train
for i=1:length(T0)
    SEerr_von(i) = (X0_predicted_final_von(i)-T0(i))^2;

end
MSE_von = mean(SEerr_von(1:length(T0)));

%% RMSPE Train
for i=1:length(T0)
    SPE_von(i) = (((X0_predicted_final_von(i)-T0(i))/T0(i))^2)*100;

end
RMSPE_von = sqrt(mean(SPE_von(1:length(T0))));
%% IA Train
for i=1:length(T0)
    IA_1(i)=(X0_predicted_final_von(i)-T0(i))^2;
    IA_2(i)=(abs(X0_predicted_final_von(i)-mean(T0))+abs(mean(T0)-T0(i)))^2;
end
IA_von = 1-(sum(IA_1)/sum(IA_2));

%% R Train
R_von = cov(T0, X0_predicted_final_von(1:length(T0)))/sqrt(var(T0)*var(X0_predicted_final_von(1:length(T0))));

%% display Train
disp('err von:');
disp(m_von_err)

disp('MAE von:');
disp(MAE_von)

disp('MSE von:');
disp(MSE_von)

disp('RMSPE von');
disp(RMSPE_von);

disp('IA von');
disp(IA_von);

disp(' R von');
disp(R_von)

%% APE Test
for i=(length(T0)+1):(length(T0)+length(T0_test))
    err_von_test(i) = (abs(X0_predicted_final_von(i)-T0_test(i-(length(T0))))/T0_test(i-(length(T0))))*100;

end

%% MAPE Test
m_von_err_test=mean(err_von_test(length(T0)+1:length(T0_test)+length(T0)));

%% MAE Test
for i=(length(T0)+1):(length(T0)+length(T0_test))
    AE_von_test(i) = abs(X0_predicted_final_von(i)-T0_test(i-(length(T0))));

end
MAE_von_test = mean(AE_von_test(length(T0)+1:length(T0_test)+length(T0)));

%% MSE Test
for i=(length(T0)+1):(length(T0)+length(T0_test))
    SE_von_test(i) = (X0_predicted_final_von(i)-T0_test(i-(length(T0))))^2;

end
MSE_von_test = mean(SE_von_test(length(T0)+1:length(T0_test)+length(T0)));

%% RMSPE Test
for i=(length(T0)+1):(length(T0)+length(T0_test))
    SPE_von_test(i) = (((X0_predicted_final_von(i)-T0_test(i-(length(T0))))/T0_test(i-(length(T0))))^2)*100;

end
RMSPE_von_test = sqrt(mean(SPE_von_test(length(T0)+1:length(T0_test)+length(T0))));

%% IA Test
for i=(length(T0)+1):(length(T0)+length(T0_test))
    IA_1_test(i) = (X0_predicted_final_von(i)-T0_test(i-(length(T0))))^2;
    IA_2_test(i) = (abs(X0_predicted_final_von(i)-mean(T0_test))+abs(mean(T0_test)-T0_test(i-(length(T0)))))^2;
end
IA_von_test = 1-(sum(IA_1_test)/sum(IA_2_test));

%% R Test
R_von_test = cov(T0_test, X0_predicted_final_von(length(T0)+1:length(T0_test)+length(T0)))/sqrt(var(T0_test)*var(X0_predicted_final_von(length(T0)+1:length(T0_test)+length(T0))));

%% display Test
disp('test err von:');
disp(m_von_err_test)

disp('test MAE von:');
disp(MAE_von_test)

disp('test MSE von:');
disp(MSE_von_test)

disp('test RMSPE von');
disp(RMSPE_von_test);

disp('test IA von');
disp(IA_von_test);

disp('test R von');
disp(R_von_test)
